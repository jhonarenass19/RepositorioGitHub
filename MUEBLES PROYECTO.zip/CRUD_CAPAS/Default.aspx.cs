﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CRUD.BusinessLayer;
using CRUD.EntityLayer;

namespace CRUD_CAPAS
{
    public partial class _Default : Page
    {
        MuebleBL mueBL = new MuebleBL();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            MuestraMueble();
        }

        private void MuestraMueble()
        {
            List<Mueble> lista = mueBL.Lista();
            GVMueble.DataSource = lista;
            GVMueble.DataBind();
        }

        protected void Nuevo_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Contact.aspx?idMueble=0");
        }

        protected void Editar_Click(object sender, EventArgs e)
        {
           LinkButton btn = (LinkButton)sender;
            string idmueble = btn.CommandArgument;
            Response.Redirect($"~/Contact.aspx?idMueble={idmueble}");

        }
                
        protected void Eliminar_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string idmueble = btn.CommandArgument;

            bool rpta = mueBL.eliminar(Convert.ToInt32(idmueble));
            if (rpta)
                MuestraMueble();

        }


    }
}