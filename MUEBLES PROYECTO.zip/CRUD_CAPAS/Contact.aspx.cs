﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CRUD.BusinessLayer;
using CRUD.EntityLayer;
using System.Globalization;

namespace CRUD_CAPAS
{
    public partial class Contact : Page
    {
        private static int idmueble = 0;
        CategoryBL cateBL = new CategoryBL();
        MuebleBL mueBL = new MuebleBL();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Request.QueryString["idMueble"] != null)
                {
                    idmueble = Convert.ToInt32(Request.QueryString["idMueble"].ToString());
                    if (idmueble != 0)
                    {
                        lblTitulo.Text = "Editar Mueble";
                        btnSubmit.Text = "Actualizar";
                        Mueble p = mueBL.Obtener(idmueble);
                        txtNombreCompleto.Text = p.NombreMue;
                        CargaDepartamentos(p.Categoria.IdCategoria.ToString());
                        txtPrecio.Text = p.Precio.ToString();
                        txtStock.Text = p.Stock;
                        txtNombreCliente.Text = p.NombreCli;
                        txtFechaCompra.Text = Convert.ToDateTime(p.FechaCompra,
                            new CultureInfo("es-PE")).ToString("yyyy-MM-dd");
                    }
                    else
                    {
                        lblTitulo.Text = "Nuevo Mueble";
                        btnSubmit.Text = "Guardar";
                        CargaDepartamentos();
                    }
                }
                else
                    Response.Redirect("~/Default.aspx");
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Mueble p = new Mueble()
            {
                IdMueble = idmueble,
                NombreMue = txtNombreCompleto.Text,
                Categoria = new Category() 
                { IdCategoria = Convert.ToInt32(ddlCategoria.SelectedValue) },
                Precio = Convert.ToDecimal(txtPrecio.Text),
                FechaCompra = txtFechaCompra.Text,
                Stock = txtStock.Text,
                NombreCli = txtNombreCliente.Text
         };
        bool rpta;
            if (idmueble != 0)
                rpta = mueBL.editar(p);
            else
                rpta = mueBL.nuevo(p);
            if (rpta)
                Response.Redirect("~/Default.aspx");
            else
                ScriptManager.RegisterStartupScript(this,
                    this.GetType(),"Script","alert('No se pudo" +
                    " realizar la operación')",true);
        }


        private void CargaDepartamentos(string idCat = "")
        {
            List<Category> lista = cateBL.Lista();
            ddlCategoria.DataTextField = "NombreCategoria";
            ddlCategoria.DataValueField = "IdCategoria";
            ddlCategoria.DataSource = lista;
            ddlCategoria.DataBind();

            if(idCat != "")
                ddlCategoria.SelectedValue=idCat;
        }

    }
}